utils::globalVariables(c("Probability", "Causes"))
