library(testthat)
library(InterVA5)

test_check("InterVA5")
