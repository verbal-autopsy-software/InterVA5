# InterVA5 - changes

Version 1.0.3 (2018-11-11) 
==========================
* Fix output csv file format error

Version 1.0.2 (2018-07-16)
==========================
* Add InSilicoVA rule of data check.
* Fix typo in checking WHO 2016 input using InterVA5 rules.
