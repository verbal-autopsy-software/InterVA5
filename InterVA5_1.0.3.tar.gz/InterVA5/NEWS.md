# InterVA5 - changes

Version 1.0.3 (2018-11-20) 
==========================
* Fix output csv file format error
* Fix an extra space in cause-of-death name string 'Other and unspecified NCD'

Version 1.0.2 (2018-07-16)
==========================
* Add InSilicoVA rule of data check.
* Fix typo in checking WHO 2016 input using InterVA5 rules.
